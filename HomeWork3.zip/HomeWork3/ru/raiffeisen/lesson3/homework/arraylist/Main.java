package ru.raiffeisen.lesson3.homework.arraylist;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        MyArrayList<String> myList = new MyArrayList<>(5);

        myList.add("one");
        myList.add("two");
        myList.add("three");
        myList.add("four");
        String five = "five";
        myList.add(five);
        System.out.println(myList);

        myList.add("six");
        myList.add(five);
        System.out.println(myList);

        myList.add(0, "zero");
        myList.add(8, "seven");
        System.out.println(myList);

        System.out.println(myList.indexOf(five));
        System.out.println(myList.lastIndexOf(five));
        System.out.println(myList.get(3));

        MyArrayList<String> strings = new MyArrayList<>();
        strings.add("eight");
        strings.add("nine");
        strings.add("ten");
        myList.addAll(strings);
        System.out.println(myList);

        MyArrayList<String> negativeStrings = new MyArrayList<>();
        negativeStrings.add("-two");
        negativeStrings.add("-one");
        myList.addAll(0, negativeStrings);
        System.out.println(myList);
        System.out.println(myList.containsAll(strings));

        System.out.println(myList.contains("six"));
        System.out.println(myList.contains("eleven"));

        System.out.println(myList.remove(8));
        System.out.println(myList.remove(five));
        System.out.println(myList);

        System.out.println(myList.removeAll(negativeStrings));
        System.out.println(myList);

        myList.set(9, "ten and half");
        System.out.println(myList);
        System.out.println(myList.containsAll(strings));

        System.out.println(myList.subList(1, 3));
        System.out.println(myList.isEmpty());

        Object[] objectsArray = myList.toArray();
        System.out.println(Arrays.toString(objectsArray));

        String[] stringArray = new String[20];
        myList.toArray(stringArray);
        System.out.println(Arrays.toString(stringArray));

        System.out.println(myList);
        myList.retainAll(strings);
        System.out.println(myList);
        //myList.retainAll(negativeStrings);
        //System.out.println(myList);

        myList.clear();
        System.out.println(myList);
    }
}
