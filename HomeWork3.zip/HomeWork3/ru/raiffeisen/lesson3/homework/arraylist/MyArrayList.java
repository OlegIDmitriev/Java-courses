package ru.raiffeisen.lesson3.homework.arraylist;

import java.util.*;

public class MyArrayList<E> implements Collection<E>, List<E> {
    private int size = 0;
    private int capacity = 10;
    private E[] array;

    public MyArrayList() {
        array = (E[]) new Object[capacity];
    }

    public MyArrayList(int capacity) {
        this.capacity = capacity;
        array = (E[]) new Object[capacity];
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> c) {
        if (size + c.size() > capacity) {
            capacity += c.size();
        }

        E[] newArray = (E[]) new Object[capacity];

        System.arraycopy(array, 0, newArray, 0, index);
        System.arraycopy(array, index, newArray, index + c.size(), size - index);

        array = newArray;

        for (E element : c) {
            set(index, element);
            index++;
        }
        size += c.size();

        return true;
    }

    @Override
    public E get(int index) {
        return array[index];
    }

    @Override
    public E set(int index, E element) {
        E previous = get(index);
        array[index] = element;

        return previous;
    }

    @Override
    public void add(int index, E element) {
        if (size == capacity) {
            capacity = capacity * 3 / 2 + 1;
        }

        E[] newArray = (E[]) new Object[capacity];

        System.arraycopy(array, 0, newArray, 0, index);
        System.arraycopy(array, index, newArray, index + 1, size - index);

        array = newArray;
        array[index] = element;
        size++;
    }

    @Override
    public E remove(int index) {
        E element = get(index);

        E[] newArray = (E[]) new Object[capacity];

        System.arraycopy(array, 0, newArray, 0, index);
        System.arraycopy(array, index + 1, newArray, index, size - index - 1);

        array = newArray;
        size--;

        return element;
    }

    @Override
    public int indexOf(Object o) {
        if (o == null) {
            return -1;
        }

        E obj = (E) o;

        for (int i = 0; i < size; i++) {
            if (array[i].equals(obj)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int lastIndexOf(Object o) {
        if (o == null) {
            return -1;
        }

        E obj = (E) o;

        for (int i = size - 1; i >= 0; i--) {
            if (array[i].equals(obj)) {
                return i;
            }
        }
        return -1;

    }

    @Override
    public ListIterator<E> listIterator() {
        return new MyListIterator<E>();
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        return new MyListIterator<E>(index);
    }

    @Override
    public List<E> subList(int fromIndex, int toIndex) {
        List<E> list = new MyArrayList<>();

        for (int i = fromIndex; i < toIndex; i++) {
            list.add(array[i]);
        }
        return list;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        if (size == 0) {
            return true;
        }
        return false;
    }

    @Override
    public boolean contains(Object o) {
        if (indexOf(o) != -1) {
            return true;
        }
        return false;
    }

    @Override
    public Iterator<E> iterator() {
        return new MyListIterator<E>();
    }

    @Override
    public Object[] toArray() {
        Object[] returnedArray = new Object[size];
        System.arraycopy(array, 0, returnedArray, 0, size);

        return returnedArray;
    }

    @Override
    public <T> T[] toArray(T[] a) {
        if (a.length >= size) {
            System.arraycopy(array, 0, a, 0, size);

            for (int i = size; i < a.length; i++) {
                a[i] = null;
            }
        }
        T[] returnedArray = (T[]) new Object[size];
        System.arraycopy(array, 0, returnedArray, 0, size);

        return returnedArray;
    }

    @Override
    public boolean add(E e) {
        if (size == capacity) {
            capacity = capacity * 3 / 2 + 1;

            E[] newArray = (E[]) new Object[capacity];
            System.arraycopy(array, 0, newArray, 0, size);
            array = newArray;
        }
        array[size] = e;
        size++;

        return true;
    }

    @Override
    public boolean remove(Object o) {
        int index = indexOf(o);
        if (index != -1) {
            remove(index);
            return true;
        }

        return false;
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        for (Object o : c) {
            if (!contains(o)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        for (E element : c) {
            add(element);
        }
        return true;
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        boolean result = false;

        for (Object o : c) {
            if (remove(o)) {
                result = true;
            }
        }

        return result;
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        boolean result = false;

        for (int i = 0; i < size(); ) {
            if (!c.contains(array[i])) {
                remove(i);
                result = true;
            } else {
                i++;
            }
        }
        return result;
    }

    @Override
    public void clear() {
        array = (E[]) new Object[capacity];
        size = 0;
    }

    @Override
    public String toString() {
        //return Arrays.toString(array);

        StringBuilder sb = new StringBuilder("[ ");

        for (int i = 0; i < size; i++) {
            sb.append(array[i]);
            if (i != size - 1) {
                sb.append(", ");
            }
        }

        sb.append(" ] " + "size: " + size() );

        return sb.toString();
    }

    private class MyListIterator<T> implements ListIterator<T> {
        private T lastElement = null;
        private int cursor = 0;

        public MyListIterator() {
        }

        public MyListIterator(int cursor) {
            this.cursor = cursor;
        }

        @Override
        public boolean hasNext() {
            if (cursor < size) {
                return true;
            }
            return false;
        }

        @Override
        public T next() {
            T element = (T) get(cursor);
            lastElement = element;
            cursor++;
            return element;
        }

        @Override
        public boolean hasPrevious() {
            if (cursor > 0) {
                return true;
            }
            return false;
        }

        @Override
        public T previous() {
            T element = (T) MyArrayList.this.get(cursor);
            lastElement = element;
            cursor--;
            return element;
        }

        @Override
        public int nextIndex() {
            if (hasNext()) {
                return cursor++;
            } else {
                return size();
            }
        }

        @Override
        public int previousIndex() {
            if (hasPrevious()) {
                return cursor--;
            } else {
                return -1;
            }
        }

        @Override
        public void remove() {
            if (lastElement != null) {
                MyArrayList.this.remove(lastElement);
                lastElement = null;
            } else {
                throw new IllegalStateException();
            }
        }

        @Override
        public void set(T t) {
            if (lastElement != null) {
                MyArrayList.this.set(cursor, (E) t);
                lastElement = null;
            } else {
                throw new IllegalStateException();
            }

        }

        @Override
        public void add(T t) {
            MyArrayList.this.add(cursor, (E) t);
            cursor++;
        }
    }
}
