package ru.raiffeisen.lesson3.homework.poker;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Poker {
    private static final char[] suites = {'\u2660', '\u2663', '\u2662', '\u2661'};
    private static final String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

    public static void main(String[] args) {
        ArrayList<Card> cardList = getCardList();
        shuffle(cardList);
        System.out.println(cardList + "\n");

        dealCards(cardList);
    }

    public static ArrayList<Card> getCardList() {
        ArrayList<Card> cards = new ArrayList<>(52);
        for (int i = 0; i < values.length; i++) {
            for (int j = 0; j < suites.length; j++) {
                cards.add(new Card(suites[j], values[i]));
            }
        }

        return cards;
    }

    public static void shuffle(ArrayList<Card> cardList) {
        Random r = new Random(System.currentTimeMillis());
        for (int i = 0; i < cardList.size() * 5; i++) {
            int j = r.nextInt(cardList.size());

            Card temp = cardList.remove(j);
            cardList.add(temp);
        }

        cardList.trimToSize();

    }

    public static ArrayList<Card> getCardsForPlayer(ArrayList<Card> cards) {
        ArrayList<Card> playerCards = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            playerCards.add(cards.remove(0));
        }

        return playerCards;
    }

    public static void dealCards(ArrayList<Card> cards) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число игроков:");
        int number = scanner.nextInt();

        for (int i = 0; i < number; i++) {
            System.out.println(getCardsForPlayer(cards) + "\n");
        }
    }
}
