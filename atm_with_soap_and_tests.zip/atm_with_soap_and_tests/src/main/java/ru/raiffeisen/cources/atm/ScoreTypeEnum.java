package main.java.ru.raiffeisen.cources.atm;

public enum ScoreTypeEnum {
    CREDIT,
    DEBET,
    CURRENT
}
