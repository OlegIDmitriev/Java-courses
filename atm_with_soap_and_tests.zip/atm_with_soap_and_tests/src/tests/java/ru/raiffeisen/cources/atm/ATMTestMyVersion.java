package tests.java.ru.raiffeisen.cources.atm;

import main.java.ru.raiffeisen.cources.atm.ATM;
import main.java.ru.raiffeisen.cources.atm.ScoreTypeEnum;
import main.java.ru.raiffeisen.cources.atm.model.db.DAO.AtmDAO;
import main.java.ru.raiffeisen.cources.atm.model.db.SingleConnectionManager;
import main.java.ru.raiffeisen.cources.atm.model.money.Money;
import main.java.ru.raiffeisen.cources.atm.model.score.CurrentScore;
import main.java.ru.raiffeisen.cources.atm.model.score.DebetScore;
import main.java.ru.raiffeisen.cources.atm.model.score.DumpType;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import tests.java.ru.raiffeisen.cources.atm.data.AtmDataSupplier;
import tests.java.ru.raiffeisen.cources.atm.data.TestPair;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ATMTestMyVersion {
    private static ATM atm;
    private static final AtmDataSupplier atmDataSupplier = new AtmDataSupplier();

    private static final String DUMP_STR = "{\"currentScore\":{\"debetScore\":{\"creditScore\":{\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":1.0},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":1.0},\"value\":1000.0},\"number\":2,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":1.0},\"value\":1000.0},\"number\":3,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"debetScore\":{\"creditScore\":{\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":1.0},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":1.0},\"value\":1000.0},\"number\":2,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"creditScore\":{\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":1.0},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"operLimit\":0,\"currentOpers\":0,\"operLimitToggl\":false}";

    @BeforeAll
    static void init() {
        atm = atmDataSupplier.getStartDataATM();
    }

    @BeforeEach
    void fillData() {
        atmDataSupplier.fillATM(atm);
    }

    @ParameterizedTest
    @EnumSource(ScoreTypeEnum.class)
    void addMoneyToScore(ScoreTypeEnum scoreTypeEnum) {
        int i = 1;
        for (TestPair<Money> pair : atmDataSupplier.getTestListDataForAddMoney(atm)) {
            System.out.println("Try #: " + i++);
            fillData();
            atm.addMoneyToScore(pair.getTestValue(), scoreTypeEnum);
            Money newMoney = atmDataSupplier.getMoneyFromScore(atm, scoreTypeEnum);
            assertEquals(pair.getExpectedValue(), newMoney);
        }
    }

    @ParameterizedTest
    @EnumSource(ScoreTypeEnum.class)
    void getMoneyFromScore(ScoreTypeEnum scoreTypeEnum) {
        int i = 1;
        for (TestPair<Money> pair : atmDataSupplier.getTestListDataForGetMoneyCurrent(atm)) {
            System.out.println("Try #: " + i++);
            fillData();
            atm.getMoneyFromScore(pair.getTestValue(), scoreTypeEnum);
            Money newMoney = atmDataSupplier.getMoneyFromScore(atm, scoreTypeEnum);
            assertEquals(pair.getExpectedValue(), newMoney);
        }
    }

    @Test
    void getMoneyFromCurrentScore() {
        int i = 1;
        for (TestPair<Money> pair : atmDataSupplier.getTestListDataForGetMoneyCurrent(atm)) {
            System.out.println("Try #: " + i++);
            fillData();
            atm.getMoneyFromScore(pair.getTestValue(), ScoreTypeEnum.CURRENT);
            Money newMoney = atmDataSupplier.getMoneyFromScore(atm, ScoreTypeEnum.CURRENT);
            assertEquals(pair.getExpectedValue(), newMoney);
        }
    }

    @Test
    void getMoneyFromCreditScore() {
        int i = 1;
        for (TestPair<Money> pair : atmDataSupplier.getTestListDataForGetMoneyCredit(atm)) {
            System.out.println("Try #: " + i++);
            fillData();
            atm.getMoneyFromScore(pair.getTestValue(), ScoreTypeEnum.CREDIT);
            Money newMoney = atmDataSupplier.getMoneyFromScore(atm, ScoreTypeEnum.CREDIT);
            assertEquals(pair.getExpectedValue(), newMoney);
        }
    }

    @Test
    void getMoneyFromDebetScore() {
        int i = 1;
        for (TestPair<Money> pair : atmDataSupplier.getTestListDataForGetMoneyCredit(atm)) {
            System.out.println("Try #: " + i++);
            fillData();
            atm.getMoneyFromScore(pair.getTestValue(), ScoreTypeEnum.DEBET);
            Money newMoney = atmDataSupplier.getMoneyFromScore(atm, ScoreTypeEnum.DEBET);
            assertEquals(pair.getExpectedValue(), newMoney);
        }
    }

    @Test
    void getATMFromJSONString() {
        StringBuilder stringBuilder = new StringBuilder(DUMP_STR);
        ATM newAtm = atm.getATMFromJSONString(stringBuilder);

        assertEquals(atm, newAtm);
    }

    @Test
    void getAllScoresBalanceFromDB() {
        AtmDAO atmDAO = mock(AtmDAO.class);
        when(atmDAO.getAtm()).thenReturn(atmDataSupplier.getStartDataATM());
        atm.setAtmDAO(atmDAO);

        double actualSum = atm.getAllScoresBalanceFromDB();

        assertEquals(0, actualSum);
    }

    @Test
    void restoreFromDB() {
        AtmDAO atmDAO = mock(AtmDAO.class);
        when(atmDAO.getAtm()).thenReturn(atmDataSupplier.getStartDataATM());
        atm.setAtmDAO(atmDAO);

        atm.restore(DumpType.DB);

        assertEquals(atmDataSupplier.getStartDataATM(), atm);
    }


    @Test
    void dump() {

    }

    @Test
    void restoreFromJSON() {
        atm.restoreFromJSON();

        assertEquals(new ATM(), atm);
    }

    @Test
    void getAtmDAO() {
        AtmDAO atmDAO = new AtmDAO(new SingleConnectionManager());

        assertEquals(atmDAO, atm.getAtmDAO());
    }

    @Test
    void setAtmDAO() {
        AtmDAO atmDAO = new AtmDAO(new SingleConnectionManager());
        atm.setAtmDAO(atmDAO);

        assertEquals(atmDAO, atmDataSupplier.getAtmDAOFromATM(atm));
    }

    @Test
    void getCurrentScore() {
        CurrentScore currentScore = new CurrentScore(new Money(1000, "RUR"), null, 3, null);
        assertEquals(currentScore, atm.getCurrentScore());
    }

    @Test
    void setCurrentScore() {
        CurrentScore currentScore = new CurrentScore(new Money(500, "RUR"), null, 101, null);
        atm.setCurrentScore(currentScore);
        assertEquals(currentScore, atmDataSupplier.getScoreFromATM(atm, ScoreTypeEnum.CURRENT));
    }

    @Test
    void getDebetScore() {
        DebetScore debetScore = new DebetScore(new Money(1000, "RUR"), null, 2, null);
        assertEquals(debetScore, atm.getDebetScore());
    }

    @Test
    void setDebetScore() {
        DebetScore debetScore = new DebetScore(new Money(500, "RUR"), null, 102, null);
        atm.setDebetScore(debetScore);
        assertEquals(debetScore, atmDataSupplier.getScoreFromATM(atm, ScoreTypeEnum.DEBET));
    }

    @Test
    void copy() {
        ATM atmNew = new ATM();

        try {
            Method method = ATM.class.getDeclaredMethod("copy", ATM.class);
            method.setAccessible(true);
            method.invoke(atm, atmNew);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        assertEquals(atmNew, atm);
    }

    @Test
    void dumpToJSON() {
        try {
            Method method = ATM.class.getDeclaredMethod("dumpToJSON", null);
            method.setAccessible(true);
            method.invoke(atm);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        assertEquals(DUMP_STR, atmDataSupplier.getJSONStringFromFile());
    }


    @AfterEach
    void cleanData() {
        atmDataSupplier.fillATM(atm);
    }

    @AfterAll
    static void cleanUp() {
        atm = null;
    }

}
