package tests.java.ru.raiffeisen.cources.atm;

import main.java.ru.raiffeisen.cources.atm.ATM;
import main.java.ru.raiffeisen.cources.atm.ScoreTypeEnum;
import main.java.ru.raiffeisen.cources.atm.model.constants.CurrencyHolder;
import main.java.ru.raiffeisen.cources.atm.model.db.DAO.AtmDAO;
import main.java.ru.raiffeisen.cources.atm.model.money.Money;
import main.java.ru.raiffeisen.cources.atm.model.score.CreditScore;
import main.java.ru.raiffeisen.cources.atm.model.score.CurrentScore;
import main.java.ru.raiffeisen.cources.atm.model.score.DebetScore;
import org.junit.jupiter.api.*;
import tests.java.ru.raiffeisen.cources.atm.data.AtmDataSupplier;
import tests.java.ru.raiffeisen.cources.atm.data.TestPair;

import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ATMTest {
    private static ATM atm;
    private static final AtmDataSupplier atmDataSupplier = new AtmDataSupplier();

    private static final String DUMP_STR = "{\"currentScore\":{\"debetScore\":{\"creditScore\":{\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":65.5},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":65.5},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":65.5},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"debetScore\":{\"creditScore\":{\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":65.5},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":65.5},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"creditScore\":{\"balance\":{\"currency\":{\"name\":\"RUR\",\"usdCource\":65.5},\"value\":1000.0},\"number\":1,\"methodConstraintMap\":{},\"methodCallMap\":{},\"methodConstraintToggl\":false},\"operLimit\":0,\"currentOpers\":0,\"operLimitToggl\":false}";

    @BeforeAll
    static void init(){
        atm = atmDataSupplier.getStartDataATM();
    }

    @BeforeEach
    void fillData(){
        atmDataSupplier.fillATM(atm);
    }

    @Test
    void addMoneyToScore() {
        Map<Integer, Money> testData = atmDataSupplier.getTestData();
        Map<Integer, Money> expectedData = atmDataSupplier.getExpectedData(atm);
        for (Integer key:
                testData.keySet()) {
            Money tempMoney = testData.get(key);
            atm.addMoneyToScore(tempMoney, ScoreTypeEnum.CREDIT);

            Money expectedMoney = expectedData.get(key);
            Money newMoney = atmDataSupplier.getMoneyFromCredit(atm);

            assertEquals(expectedMoney.getValue() , newMoney.getValue());
        }
    }

    @Test
    void addMoneyToScoreSecond() {
        for (TestPair<Money> pair:
             atmDataSupplier.getTestListDataForAddMoney(atm)) {
            assertEquals(pair.getExpectedValue(), pair.getTestValue());
        }
    }

    @Test
    void getATMFromJSONString(){
        StringBuilder stringBuilder = mock(StringBuilder.class);
        when(stringBuilder.toString()).thenReturn(DUMP_STR);

        ATM newAtm = atm.getATMFromJSONString(stringBuilder);

        assertEquals(atm, newAtm);
    }

    @Test
    void getAllScoresBalanceFromDB(){
        AtmDAO atmDAO = mock(AtmDAO.class);
        when(atmDAO.getAtm()).thenReturn(atmDataSupplier.getStartDataATM());
        atm.setAtmDAO(atmDAO);

        double actualSum = atm.getAllScoresBalanceFromDB();

        assertEquals(0, actualSum);
    }

    @Test
    void getMoneyFromScore(){

    }

    @Test
    void restore(){

    }

    @Test
    void dump(){

    }


    @AfterEach
    void cleanData(){
        atmDataSupplier.fillATM(atm);
    }

    @AfterAll
    static void cleanUp(){
        atm = null;
    }

}