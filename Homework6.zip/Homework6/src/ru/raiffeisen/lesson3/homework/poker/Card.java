package ru.raiffeisen.lesson3.homework.poker;

public class Card {
    private final char suite;
    private final String value;

    public Card(char suite, String value) {
        this.suite = suite;
        this.value = value;
    }

    public char getSuite() {
        return suite;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value + suite;
    }
}
