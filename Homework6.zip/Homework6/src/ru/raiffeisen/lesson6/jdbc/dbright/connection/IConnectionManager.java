package ru.raiffeisen.lesson6.jdbc.dbright.connection;

import java.sql.Connection;

public interface IConnectionManager {
    Connection getConnection();
}
