package ru.raiffeisen.lesson6.jdbc.dbright;

import ru.raiffeisen.lesson6.jdbc.dbright.DAO.PrisonerDAO;
import ru.raiffeisen.lesson6.jdbc.dbright.connection.PooledConnectionManager;
import ru.raiffeisen.lesson6.jdbc.dbright.connection.SingleConnectionManager;

public class Main {
    public static void main(String[] args) {
        PrisonerDAO prisonerDAO = new PrisonerDAO(
                                        new PooledConnectionManager(50)
        );

        System.out.println(prisonerDAO.getAllPrisoners());
    }
}
