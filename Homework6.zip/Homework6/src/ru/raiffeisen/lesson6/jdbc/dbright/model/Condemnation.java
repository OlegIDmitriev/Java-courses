package ru.raiffeisen.lesson6.jdbc.dbright.model;

public class Condemnation {
    private int id;
    private String description;
    private int years;

    public Condemnation(int id, String description, int years) {
        this.id = id;
        this.description = description;
        this.years = years;
    }

    @Override
    public String toString() {
        return "Condemnation{" +
                "id=" + id +
                ", description='" + description + '\'' +
                ", years=" + years +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getYears() {
        return years;
    }

    public void setYears(int years) {
        this.years = years;
    }
}
