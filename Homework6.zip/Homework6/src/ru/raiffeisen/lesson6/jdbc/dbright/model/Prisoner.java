package ru.raiffeisen.lesson6.jdbc.dbright.model;

public class Prisoner {
    private int id;
    private String name;
    private PrisonerRole prisonerRole;
    private Camera camera;
    private Condemnation condemnation;

    public Prisoner(int id, String name, PrisonerRole prisonerRole, Camera camera, Condemnation condemnation) {
        this.id = id;
        this.name = name;
        this.prisonerRole = prisonerRole;
        this.camera = camera;
        this.condemnation = condemnation;
    }

    @Override
    public String toString() {
        return "Prisoner{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", prisonerRole=" + prisonerRole +
                ", camera=" + camera +
                ", condemnation=" + condemnation +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PrisonerRole getPrisonerRole() {
        return prisonerRole;
    }

    public void setPrisonerRole(PrisonerRole prisonerRole) {
        this.prisonerRole = prisonerRole;
    }

    public Camera getCamera() {
        return camera;
    }

    public void setCamera(Camera camera) {
        this.camera = camera;
    }

    public Condemnation getCondemnation() {
        return condemnation;
    }

    public void setCondemnation(Condemnation condemnation) {
        this.condemnation = condemnation;
    }
}
