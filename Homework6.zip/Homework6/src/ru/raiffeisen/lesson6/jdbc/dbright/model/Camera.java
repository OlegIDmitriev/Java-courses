package ru.raiffeisen.lesson6.jdbc.dbright.model;

public class Camera {
    private int id;
    private int number;
    private int placesCount;

    public Camera(int id, int number, int placesCount) {
        this.id = id;
        this.number = number;
        this.placesCount = placesCount;
    }

    @Override
    public String toString() {
        return "Camera{" +
                "id=" + id +
                ", number=" + number +
                ", placesCount=" + placesCount +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getPlacesCount() {
        return placesCount;
    }

    public void setPlacesCount(int placesCount) {
        this.placesCount = placesCount;
    }
}

