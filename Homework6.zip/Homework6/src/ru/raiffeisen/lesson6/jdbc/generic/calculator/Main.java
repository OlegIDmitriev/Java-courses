package ru.raiffeisen.lesson6.jdbc.generic.calculator;

public class Main {
    public static void main(String[] args) {
        GenericCalc<String, Integer, Float> genericCalc =
                new GenericCalc<>("mes",
                                                            1,
                                                         2.5f);
        genericCalc.setValue1("hi");
        genericCalc.setValue2(11);
        genericCalc.setValue3(42.5f);

        GenericCalc<?, ? super Child, ?> genericCalc1;
        //genericCalc1 = new GenericCalc<Comparable, Parent, Object>();
        //genericCalc1 = new GenericCalc<Float, String, Object>(1.2f,"",null);
    }

    public static <Type extends Parent, Type2 extends Comparable> Type genMethod(Type2 type2){
        type2.compareTo("message");

        return (Type) new Parent();
    }
}
