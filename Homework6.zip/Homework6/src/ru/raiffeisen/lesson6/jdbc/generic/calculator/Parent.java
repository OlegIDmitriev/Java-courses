package ru.raiffeisen.lesson6.jdbc.generic.calculator;

public class Parent implements Comparable {
    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
