package ru.raiffeisen.lesson6.jdbc.generic;

public class StringBox {
    public StringBox(String value) {
        this.value = value;
    }

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
