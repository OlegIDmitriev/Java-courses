package ru.raiffeisen.lesson6.jdbc.generic.calculator;

public class Child extends Parent {
}
