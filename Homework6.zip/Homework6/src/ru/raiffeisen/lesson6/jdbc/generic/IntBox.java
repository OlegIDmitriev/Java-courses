package ru.raiffeisen.lesson6.jdbc.generic;

public class IntBox {
    private Integer value;

    public IntBox(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
}
