package ru.raiffeisen.lesson6.jdbc.generic;

public class FloatBox {
    private Float value;

    public FloatBox(Float value) {
        this.value = value;
    }

    public Float getValue() {
        return value;
    }

    public void setValue(Float value) {
        this.value = value;
    }
}
