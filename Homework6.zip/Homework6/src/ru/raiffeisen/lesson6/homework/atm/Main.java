package ru.raiffeisen.lesson6.homework.atm;

import ru.raiffeisen.lesson6.homework.atm.db.dao.AtmDAO;
import ru.raiffeisen.lesson6.homework.atm.model.account.Account;
import ru.raiffeisen.lesson6.homework.atm.model.account.Principal;
import ru.raiffeisen.lesson6.homework.atm.model.money.Money;
import ru.raiffeisen.lesson6.homework.atm.model.score.CreditScore;
import ru.raiffeisen.lesson6.homework.atm.model.score.CurrentScore;
import ru.raiffeisen.lesson6.homework.atm.model.score.DebetScore;
import ru.raiffeisen.lesson6.jdbc.dbright.connection.SingleConnectionManager;

import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        AtmDAO atmDAO = new AtmDAO(new SingleConnectionManager());
        ATM atm = null;

        Scanner sc = new Scanner(System.in);
        if (atmDAO.checkDump()) {
            System.out.println("Обнаружен сохраненный дамп. Наберите 'yes' чтобы загрузить или любой другой текст чтобы удалить");
            String anwer = sc.next();
            if ("yes".equals(anwer)) {
                List<ATM> atmList = atmDAO.getAllATM();
                atm = atmList.get(atmList.size()-1);
            } else {
                atmDAO.clearDB();

            }
        }
/*
        Principal principal = new Principal("John", "Dow", "James", (short) 31);
        Account account = new Account(principal, "login", "password");

        Money creditMoney = new Money(101.06d, "RUR");
        Money currentMoney = new Money(154567.01d, "RUR");
        Money debetMoney = new Money(11354.45d, "RUR");

        CreditScore creditScore = new CreditScore(creditMoney, account, 101);
        DebetScore debetScore = new DebetScore(debetMoney, account, 103, creditScore);
        CurrentScore currentScore = new CurrentScore(currentMoney, account, 102, debetScore);

        atm = new ATM(currentScore, debetScore, creditScore);

        //atm.getCreditScore().addMoney(money);

*/
        atmDAO.writeDBDump(atm);
    }
}
