package ru.raiffeisen.lesson6.homework.atm.model.money;

import ru.raiffeisen.lesson6.homework.atm.model.money.Money;

public interface MoneyInterface {
    void addMoney(Money money);
    Money getMoney(double balanceLess);
    Money getMoneyWithoutLess();
}
