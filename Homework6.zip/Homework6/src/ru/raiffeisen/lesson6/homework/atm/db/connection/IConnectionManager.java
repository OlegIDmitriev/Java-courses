package ru.raiffeisen.lesson6.homework.atm.db.connection;

import java.sql.Connection;

public interface IConnectionManager {
    Connection getConnection();
}
