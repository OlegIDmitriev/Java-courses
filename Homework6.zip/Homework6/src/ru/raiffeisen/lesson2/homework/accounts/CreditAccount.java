package ru.raiffeisen.lesson2.homework.accounts;

public class CreditAccount extends Account {
    public CreditAccount(long balance) {
        super(balance);
    }

    @Override
    public String getAccountType() {
        return "Кредитный счет";
    }
}
