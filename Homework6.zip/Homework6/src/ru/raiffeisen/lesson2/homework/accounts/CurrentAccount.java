package ru.raiffeisen.lesson2.homework.accounts;

public class CurrentAccount extends Account {
    public CurrentAccount(long balance) {
        super(balance);
    }

    @Override
    public String getAccountType() {
        return "Текущий счет";
    }
}
