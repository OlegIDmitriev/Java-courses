package ru.raiffeisen.lesson2.homework.accounts;

public class DebitAccount extends Account {
    public DebitAccount(long balance) {
        super(balance);
    }

    @Override
    public String getAccountType() {
        return "Дебетовый счет";
    }
}
