package ru.raiffeisen.lesson2.zoo;

import ru.raiffeisen.lesson2.zoo.animals.Africa.Monkey;
import ru.raiffeisen.lesson2.zoo.animals.Animal;
import ru.raiffeisen.lesson2.zoo.animals.Europe.Eagle;
import ru.raiffeisen.lesson2.zoo.cages.Cage;
import ru.raiffeisen.lesson2.zoo.cages.Padok;
import ru.raiffeisen.lesson2.zoo.cages.Volier;

public class Zoo {
    private boolean isBoughtTicket = false;

    private Cage[] cages;

    public Zoo() {
        cages = new Cage[2];

        Animal[] animalsFirst = new Animal[2];
        animalsFirst[0] = new Monkey("Aby", "Brown", true, 4);
        animalsFirst[1] = new Monkey("Mister", "Black", true, 3);
        Cage first = new Volier(animalsFirst, 10);
        cages[0] = first;

        Animal[] animalsSecond = new Animal[2];
        animalsSecond[0] = new Eagle("Zorkii", "black", (short) 10, 6);
        animalsSecond[1] = new Eagle("Metkii", "gray", (short) 5, 4);
        Cage second = new Padok(animalsSecond, 10);
        cages[1] = second;
    }

    public String getCageReport(int cageNumber) {
        if (isBoughtTicket) {
            return cages[cageNumber].getCageDescription();
        } else return "You need to buy ticket first!";
    }

    public void buyTicket() {
        isBoughtTicket = true;
        System.out.println("Thanks for buying a ticket!");

    }


    public int getCageNumberByAnimalName(String animalName) {
        if (isBoughtTicket) {
            for(int i = 0; i<cages.length; i++){
                if(cages[i].findAnimalByName(animalName))
                {
                    System.out.println("Cage number: " + i);
                    return i;
                }
            }
            System.out.println("Animal not found in zoo!");
            return -1;
        } else {
            System.out.println("You need to buy ticket first!");
            return -1;
        }
    }


}
