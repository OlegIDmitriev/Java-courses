package ru.raiffeisen.lesson2.zoo.cages;

public interface ICageDescriptor {
    String getCageDescription();
}
