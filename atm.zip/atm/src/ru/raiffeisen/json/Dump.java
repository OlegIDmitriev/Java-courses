package ru.raiffeisen.json;

import java.io.*;

public class Dump {
    private static final String dumpFileName = "dump.json";

    public static String readDump() {
        if(!checkDump()){
            return null;
        }

        final int bufferSize = 1024;
        final char[] buffer = new char[bufferSize];
        final StringBuilder out = new StringBuilder();
        try (InputStream is = new FileInputStream(dumpFileName); Reader in = new InputStreamReader(is, "UTF8")) {
            for (; ; ) {
                int rsz = in.read(buffer, 0, buffer.length);
                if (rsz < 0)
                    break;
                out.append(buffer, 0, rsz);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return out.toString();
    }

    public static void writeDump(String jsonString) {
        File file = new File(dumpFileName);
        try (
                FileOutputStream fos = new FileOutputStream(file); OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF8");  BufferedWriter bw = new BufferedWriter(osw);) {

            file.createNewFile();
            bw.write(jsonString);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static boolean checkDump() {
        File file = new File(dumpFileName);

        return file.exists();
    }
}
