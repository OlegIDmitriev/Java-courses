package ru.raiffeisen.json;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import ru.raiffeisen.atm.ATM;
import ru.raiffeisen.atm.model.account.Account;
import ru.raiffeisen.atm.model.account.Principal;
import ru.raiffeisen.atm.model.money.Money;
import ru.raiffeisen.atm.model.score.CreditScore;
import ru.raiffeisen.atm.model.score.CurrentScore;
import ru.raiffeisen.atm.model.score.DebetScore;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        ATM atm = null;

        if (Dump.checkDump()) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Обнаружен сохраненный дамп. Наберите 'yes' чтобы загрузить или любой другой текст чтобы удалить");

            String answer = sc.next();
            if ("yes".equals(answer)) {
                atm = gson.fromJson(Dump.readDump(), ATM.class);
            }
        }


        Principal principal = new Principal("John", "Dow", "James", (short) 31);
        Account account = new Account(principal, "login", "password");

        Money creditMoney = new Money(101.06d, "RUR");
        Money currentMoney = new Money(154567.01d, "RUR");
        Money debetMoney = new Money(11354.45d, "RUR");

        CreditScore creditScore = new CreditScore(creditMoney, account, 101);
        DebetScore debetScore = new DebetScore(debetMoney, account, 103, creditScore);
        CurrentScore currentScore = new CurrentScore(currentMoney, account, 102, debetScore);

        atm = new ATM(currentScore, debetScore, creditScore);

        String fromATMJSON = gson.toJson(atm);
        System.out.println(fromATMJSON);

        Dump.writeDump(fromATMJSON);

        ATM atmNEW = gson.fromJson(fromATMJSON, ATM.class);
        System.out.println(atmNEW);

        Dump.writeDump(fromATMJSON);
    }
}
