package ru.raiffeisen.atm.db.connection;

import java.sql.Connection;

public interface IConnectionManager {
    Connection getConnection();
}
