package ru.raiffeisen.atm.model;

import ru.raiffeisen.atm.ATM;
import ru.raiffeisen.atm.jaxb.ATMTransformer;
import ru.raiffeisen.atm.model.account.Account;
import ru.raiffeisen.atm.model.account.Principal;
import ru.raiffeisen.atm.model.money.Money;
import ru.raiffeisen.atm.model.score.CreditScore;
import ru.raiffeisen.atm.model.score.CurrentScore;
import ru.raiffeisen.atm.model.score.DebetScore;

import java.io.File;
import java.io.IOException;

public class MainJAXB {
    public static void main(String[] args) {

        Principal principal = new Principal("John", "Dow", "James", (short) 31);
        Account account = new Account(principal, "login", "password");

        Money creditMoney = new Money(101.06d, "RUR");
        Money currentMoney = new Money(154567.01d, "RUR");
        Money debetMoney = new Money(11354.45d, "RUR");

        CreditScore creditScore = new CreditScore(creditMoney, account, 101);
        DebetScore debetScore = new DebetScore(debetMoney, account, 103, creditScore);
        CurrentScore currentScore = new CurrentScore(currentMoney, account, 102, debetScore);

        ATM atm = new ATM(currentScore, debetScore, creditScore);

        String xmlDumpName = "atmDump.xml";
        ATMTransformer.jaxbObjectToXML(atm, xmlDumpName);

        ATM atmNew  =(ATM) ATMTransformer.jaxbXMLToObject(xmlDumpName, ATM.class);
        System.out.println(atmNew);

    }
}
