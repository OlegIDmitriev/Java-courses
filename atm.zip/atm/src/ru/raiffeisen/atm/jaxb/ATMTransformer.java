package ru.raiffeisen.atm.jaxb;

import ru.raiffeisen.atm.ATM;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.*;

public class ATMTransformer {

    public static Object jaxbXMLToObject(File file, Class clss) {
        try {
            JAXBContext context = JAXBContext.newInstance(clss);
            Unmarshaller un = context.createUnmarshaller();
            Object object = un.unmarshal(file);

            return object;
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Object jaxbXMLToObject(String path, Class clss) {
        try(InputStream is = new FileInputStream(path); Reader in = new InputStreamReader(is, "UTF8")) {
            JAXBContext context = JAXBContext.newInstance(clss);
            Unmarshaller un = context.createUnmarshaller();
            Object object = un.unmarshal(in);

            return object;
        } catch (JAXBException e) {
            e.printStackTrace();
        } catch (IOException io) {
            io.printStackTrace();
        }
        return null;
    }


    public static void jaxbObjectToXML(Object object, String path) {

        try {
            File file  = new File(path);
            file.createNewFile();

            JAXBContext context = JAXBContext.newInstance(object.getClass());
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            m.marshal(object, file);
        } catch (JAXBException e) {
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
