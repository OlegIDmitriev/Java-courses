package ru.raiffeisen.atm;

import ru.raiffeisen.atm.model.score.CreditScore;
import ru.raiffeisen.atm.model.score.CurrentScore;
import ru.raiffeisen.atm.model.score.DebetScore;

public interface ATMInterface {
    CurrentScore getCurrentScore();

    void setCurrentScore(CurrentScore currentScore);

    DebetScore getDebetScore();

    void setDebetScore(DebetScore debetScore);

    CreditScore getCreditScore();

    void setCreditScore(CreditScore creditScore);
}
