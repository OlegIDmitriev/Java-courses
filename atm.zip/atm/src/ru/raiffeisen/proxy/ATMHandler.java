package ru.raiffeisen.proxy;



import ru.raiffeisen.atm.ATMInterface;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class ATMHandler implements InvocationHandler {
    private ATMInterface atmInterface;

    public ATMHandler(ATMInterface atmInterface) {
        this.atmInterface = atmInterface;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object result = method.invoke(atmInterface, args);

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long totalTime = System.currentTimeMillis() - startTime;

        if (totalTime > 2000) {
            doSomething(method);
        }
        return result;
    }

    private void doSomething( Method method){
        System.out.println("Метод "  + method.getName() + " вызывается больше 2 с!");
    }
}
