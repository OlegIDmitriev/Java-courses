package ru.raiffeisen.lesson1.homework;

import java.util.ArrayList;
import java.util.Scanner;

public class StringFilter {
    public static void main(String[] args) {

        String[] arrayForCheck = readLine(); //Если ввели несколько строк через пробелы
        //String[] arrayForCheck = readLines(); //Если мы хотим ввести несколько строк c переносом

        printStringsThatContainsFilter(arrayForCheck, args);  //Для поиска строк содержащих подстроки из массива строк
        //printStringsThatMatchesRegexp(arrayForCheck, args); //Для поиска строк по регулярным выраженияи

    }

    public static String[] readLine() {
        System.out.println("Введите строки для проверки:");

        Scanner sc = new Scanner(System.in);
        String inputString = sc.nextLine();

        return inputString.split("\\s");
    }

    public static String[] readLines() {
        System.out.println("Введите строки для проверки. Наберите 'stop' чтобы окончить ввод");
        ArrayList<String> inputList = new ArrayList<>();

        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        while (!input.equals("stop")) {
            inputList.add(input);
            input = sc.nextLine();
        }

        String[] inputArray = new String[inputList.size()];
        inputArray = inputList.toArray(inputArray);

        return inputArray;
    }

    public static boolean containsCaseInsensitive(String stringForCheck, String filterString) {
        String stringForCheckLower = stringForCheck.toLowerCase();
        String filterStringLower = filterString.toLowerCase();

        return stringForCheckLower.contains(filterStringLower);
    }

    public static boolean containsCaseInsensitive(String stringForCheck, String[] filterStrings) {
        for (String s : filterStrings) {
            if (containsCaseInsensitive(stringForCheck, s)) {
                return true;
            }
        }
        return false;
    }

    public static void printStringsThatContainsFilter(String[] stringsForCheck, String[] filterStrings) {
        if (arrayIsEmpty(filterStrings)) {
            System.out.println("Введите подстроку для поиска!");
            return;
        }
        if (arrayIsEmpty(stringsForCheck)) {
            System.out.println("Не введена строка для проверки!");
            return;
        }
        System.out.println("Под условия фильтра подходят следуюшие строки:");
        for (String s : stringsForCheck) {
            if (containsCaseInsensitive(s, filterStrings)) {
                System.out.println(s);
            }
        }
    }

    public static boolean arrayIsEmpty(String[] args) {
        return (args == null || args.length == 0);
    }

    public static boolean matches(String stringForCheck, String[] regexpArray) {
        for (String regexp : regexpArray) {
            if (stringForCheck.matches(regexp)) {
                return true;
            }
        }
        return false;
    }

    public static void printStringsThatMatchesRegexp(String[] stringsForCheck, String[] regexpArray) {
        if (arrayIsEmpty(regexpArray)) {
            System.out.println("Введите регулярное выражение!");
            return;
        }
        if (arrayIsEmpty(stringsForCheck)) {
            System.out.println("Не введена строка для проверки!");
            return;
        }
        System.out.println("Под условия фильтра подходят следуюшие строки:");
        for (String s : stringsForCheck) {
            if (matches(s, regexpArray)) {
                System.out.println(s);
            }
        }
    }
}