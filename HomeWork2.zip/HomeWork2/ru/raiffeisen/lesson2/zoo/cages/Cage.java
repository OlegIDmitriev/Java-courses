package ru.raiffeisen.lesson2.zoo.cages;

import ru.raiffeisen.lesson2.zoo.animals.Animal;

public abstract class Cage implements ICageDescriptor {
    protected Animal[] animals;

    public Cage(Animal[] animals) {
        this.animals = animals;
    }

    @Override
    public String getCageDescription() {
        StringBuilder descriptionBuilder = new StringBuilder();

        for (Animal animal :
                animals) {
            descriptionBuilder.append(animal.toString());
        }

        return descriptionBuilder.toString();
    }

    public boolean findAnimalByName(String name) {
        for (Animal a : animals) {
            if (a.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }
}
