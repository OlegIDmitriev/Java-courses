package ru.raiffeisen.lesson2.zoo;

import ru.raiffeisen.lesson2.zoo.Zoo;

public class Main {
    public static void main(String[] args) {
        Zoo zoo = new Zoo();
        System.out.println(zoo.getCageReport(0));
        zoo.getCageNumberByAnimalName("Steve");

        zoo.buyTicket();
        System.out.println(zoo.getCageReport(0));
        zoo.getCageNumberByAnimalName("Steve");
        zoo.getCageNumberByAnimalName("Mister");
    }
}
