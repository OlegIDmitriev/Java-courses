package ru.raiffeisen.lesson2.homework;

import ru.raiffeisen.lesson2.homework.accounts.Account;
import ru.raiffeisen.lesson2.homework.accounts.CreditAccount;
import ru.raiffeisen.lesson2.homework.accounts.CurrentAccount;
import ru.raiffeisen.lesson2.homework.accounts.DebitAccount;

public class Main {
    public static void main(String[] args) {
        Account[] accs = new Account[3];
        accs[0] = new CreditAccount(-10000);
        accs[1] = new CurrentAccount(15000);
        accs[2] = new DebitAccount(100000);

        Bankomat bankomat = new Bankomat(accs);

        bankomat.addMoney(1, 1200000);
        bankomat.takeMoney(0, 0);
        bankomat.takeMoney(0, 10);
        bankomat.transferMoney(1,2, 12);

        for (Account a : accs){
            System.out.println(a.getBalance());
        }
    }
}
