package ru.raiffeisen.lesson2.homework;

import ru.raiffeisen.lesson2.homework.accounts.Account;
import ru.raiffeisen.lesson2.homework.accounts.CreditAccount;
import ru.raiffeisen.lesson2.homework.accounts.CurrentAccount;
import ru.raiffeisen.lesson2.homework.accounts.DebitAccount;

public class Bankomat {
    private Account[] accounts;

    public Bankomat(Account[] accounts) {
        this.accounts = accounts;
    }

    public void addMoney(int accountNumber, long sum) {
        if(debitAccountCheck(accountNumber))
        {
            return;
        }
        accounts[accountNumber].addMoney(sum);
        if(accounts[accountNumber] instanceof CurrentAccount && sum >1000000)
        {
            for (Account a : accounts) {
                if (a instanceof DebitAccount) {
                    System.out.println("Бонус! Дебетовый счет пополнен на 2000");
                    a.addMoney(2000);
                }
            }
        }
    }

    public void takeMoney(int accountNumber, long sum) {
        if(debitAccountCheck(accountNumber))
        {
            return;
        }
        accounts[accountNumber].takeMoney(sum);

    }

    public void transferMoney(int accountNumberFrom, int accountNumberTo, long sum) {
        if( debitAccountCheck(accountNumberFrom) || debitAccountCheck(accountNumberTo)) {
            return;
        }

        takeMoney(accountNumberFrom, sum);
        addMoney(accountNumberTo, sum);

    }

    private boolean debitAccountCheck(int accountNumber){
        return (accounts[accountNumber] instanceof DebitAccount && negativeCreditBalance());
    }

    private boolean negativeCreditBalance() {
        for (Account a : accounts) {
            if (a instanceof CreditAccount && a.getBalance() < -20000) {
                System.out.println("Баланс кредитного счета менее -20000. Операции с дебетовым счетом запрещены.");
                return true;
            }
        }
        return false;
    }
}

