package ru.raiffeisen.lesson2.homework.accounts;

public abstract class Account {
    private long balance;

    public Account(long balance) {
        this.balance = balance;
    }

    public void addMoney(long sum) {
        if (sum > 0) {
            this.balance += sum;
            System.out.println(getAccountType() + ": пополнение на сумму " + sum);
        } else System.out.println("Можно внести только положительную сумму");
    }

    public void takeMoney(long sum) {
        if (sum > 0 && sum <= 30000) {
            this.balance -= sum;
            System.out.println(getAccountType() + ": списание на сумму " + sum);
        } else {
            System.out.println("Можно снять любую положительную сумму не больше 30000 р. за сеанс!");
        }
    }

    public long getBalance(){
        return balance;
    }

    protected abstract String getAccountType();
}
