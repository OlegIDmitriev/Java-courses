package cources;

import cources.data.DriverPool;
import cources.data.UserPool;
import cources.pages.DeliveryClubMainPageObject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en_scouse.An;
import org.openqa.selenium.WebDriver;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class MainPageTest {
    private DeliveryClubMainPageObject page;

    @Given("^Go to (https://.*)$")
    public void preCondition(String url) {
        page = new DeliveryClubMainPageObject();
        page.init(DriverPool.instance.pollDriver());

        page.openMainPage();
        page.authorise();

    }

    @When("enter address (.*)")
    public void enterAddress(String address) {
        page.searchByAddress(address);

    }

    @And("^choose vendor (.*)$")
    public void chooseVendor(String name){
        page.chooseVendor(name);
    }

    @Then("^we see (\\d+) results$")
    public void checkCorrectAddressSearch(int resultCount) {
        page.loadVendors();
        System.out.println(page.getVendors().size());

        assertEquals(resultCount, page.getVendors().size());
        page.releaseUser();
        //page.releaseDriver();
    }

    @Then("^we see error message (.*)$")
    public void checkIncorrectResults(String message) {
        page.loadVendors();
        System.out.println(page.getVendors().size());

        assertEquals(message, page.getErrorMessage());
        //page.releaseDriver();
        page.releaseUser();
    }
}
