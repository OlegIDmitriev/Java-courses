package cources;

public interface MenuChecker {
    boolean check();
}
