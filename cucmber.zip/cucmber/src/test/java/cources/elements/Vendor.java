package cources.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


public class Vendor {
    private WebElement element;
    private String vendorName;

    public Vendor(WebElement element) {
        this.element = element;
        vendorName = element.findElement(By.xpath("//span")).getText();
    }

    public String getVendorName() {
        return vendorName;
    }

    public void click(){
        element.click();
    }
}
