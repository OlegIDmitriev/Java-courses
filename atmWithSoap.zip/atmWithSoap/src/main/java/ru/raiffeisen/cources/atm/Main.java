package ru.raiffeisen.cources.atm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import ru.raiffeisen.cources.atm.model.score.DumpType;

public class Main {

    public static void main(String[] args) {
	    ATM atm = new ATM();

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String fromATMJSON = gson.toJson(atm);

        System.out.println(fromATMJSON);

        atm.dump(DumpType.JSON);
        atm.restore(DumpType.JSON);
    }
}
