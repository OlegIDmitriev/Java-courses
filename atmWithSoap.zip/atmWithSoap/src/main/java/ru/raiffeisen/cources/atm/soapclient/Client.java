package ru.raiffeisen.cources.atm.soapclient;

import ru.raiffeisen.cources.atm.ScoreTypeEnum;
import ru.raiffeisen.cources.atm.model.money.Money;
import ru.raiffeisen.cources.atm.soap.IATM;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.MalformedURLException;
import java.net.URL;

public class Client {
    public static void main(String[] args) {
        try {
            URL url = new URL("http://localhost:9998/ws/atm");

            QName qName = new QName("http://atm.cources.raiffeisen.ru/", "ATMService");

            Service service = Service.create(url, qName);

            IATM iatm = service.getPort(IATM.class);

            iatm.addMoneyToScore(new Money(666, "RUR"), ScoreTypeEnum.CREDIT);
            iatm.addMoneyToScore(new Money(777, "RUR"), ScoreTypeEnum.DEBET);
            iatm.addMoneyToScore(new Money(888, "RUR"), ScoreTypeEnum.CURRENT);

            System.out.println(iatm.getCreditScore());
            System.out.println(iatm.getDebetScore());
            System.out.println(iatm.getCurrentScore());

            System.out.println(iatm.getMoneyFromScore(new Money(100, "RUR"), ScoreTypeEnum.CREDIT));
            System.out.println(iatm.getMoneyFromScore(new Money(100, "RUR"), ScoreTypeEnum.DEBET));
            System.out.println(iatm.getMoneyFromScore(new Money(100, "RUR"), ScoreTypeEnum.CURRENT));

        } catch(MalformedURLException mfe){
            mfe.printStackTrace();
        }
    }


}
