package ru.raiffeisen.cources.atm.model.score;

public enum DumpType {
    DB,
    JSON,
    XML
}
