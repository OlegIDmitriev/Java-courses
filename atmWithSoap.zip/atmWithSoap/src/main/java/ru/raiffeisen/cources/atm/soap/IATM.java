package ru.raiffeisen.cources.atm.soap;


import ru.raiffeisen.cources.atm.ScoreTypeEnum;
import ru.raiffeisen.cources.atm.model.money.Money;
import ru.raiffeisen.cources.atm.model.score.CreditScore;
import ru.raiffeisen.cources.atm.model.score.CurrentScore;
import ru.raiffeisen.cources.atm.model.score.DebetScore;
import ru.raiffeisen.cources.atm.model.score.DumpType;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC)
public interface IATM {

    @WebMethod
    void addMoneyToScore(@WebParam(name = "Money") Money money, @WebParam(name = "ScoreType") ScoreTypeEnum choice);

    @WebMethod
    Money getMoneyFromScore(@WebParam(name = "Money") Money money, @WebParam(name = "ScoreType") ScoreTypeEnum choice);

    @WebMethod
    void restore(@WebParam(name = "DumpType") DumpType dumpType);

    @WebMethod
    void dump(@WebParam(name = "DumpType") DumpType dumpType);

    @WebMethod
    double getAllScoresBalanceFromDB();

    @WebMethod
    CurrentScore getCurrentScore();

    @WebMethod
    DebetScore getDebetScore();

    @WebMethod
    CreditScore getCreditScore();

    @WebMethod
    void setCurrentScore(CurrentScore currentScore);

    @WebMethod
    void setDebetScore(DebetScore debetScore);

    @WebMethod
    void setCreditScore(CreditScore creditScore);
}
