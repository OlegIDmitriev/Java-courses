package ru.raiffeisen.cources.atm.model.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;

public class SingleConnectionManager implements IConnectionManager {
    public static final String DB_URL = "jdbc:postgresql://localhost:5432/atm_work";
    public static final String USER_NAME = "postgres";
    public static final String USER_PASSWORD = "Idaho_0711";

    private Connection connection;

    public SingleConnectionManager() {
        try {
            this.connection =
                    DriverManager
                            .getConnection(DB_URL,
                                    USER_NAME, USER_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Connection getConnection() {
        return this.connection;
    }

    @Override
    public String toString() {
        return "SingleConnectionManager{" +
                "connection=" + connection +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SingleConnectionManager that = (SingleConnectionManager) o;
        return Objects.equals(getConnection(), that.getConnection());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getConnection());
    }
}
