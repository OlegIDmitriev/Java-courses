package ru.raiffeisen.cources.atm.soapclient;

import ru.raiffeisen.cources.atm.ScoreTypeEnum;
import ru.raiffeisen.cources.atm.model.money.Money;
import ru.raiffeisen.cources.atm.model.score.CreditScore;
import ru.raiffeisen.cources.atm.model.score.CurrentScore;
import ru.raiffeisen.cources.atm.model.score.DebetScore;
import ru.raiffeisen.cources.atm.model.score.Score;
import ru.raiffeisen.cources.atm.soap.IATM;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.MalformedURLException;
import java.net.URL;

public class ATMClient {
    private IATM iatm = null;
    private static final String WEB_SERVICE_URL = "http://localhost:8080/atmWithSoap/atm";

    public ATMClient() {
        init();
    }

    private void init() {
        try {
            URL url = new URL(WEB_SERVICE_URL);
            QName qName = new QName("http://atm.cources.raiffeisen.ru/", "ATMService");
            Service service = Service.create(url, qName);

            iatm = service.getPort(IATM.class);
        } catch (MalformedURLException mfe) {
            mfe.printStackTrace();
        }
    }

    public void addMoneyToScore(Money money, ScoreTypeEnum choice) {
        iatm.addMoneyToScore(money, choice);
    }

    public Money getMoneyFromScore(Money money, ScoreTypeEnum choice) {
        return iatm.getMoneyFromScore(money, choice);
    }

    public CurrentScore getCurrentScore() {
        return iatm.getCurrentScore();
    }

    public DebetScore getDebetScore() {
        return iatm.getDebetScore();
    }

    public CreditScore getCreditScore() {
        return iatm.getCreditScore();
    }

    public Score getScoreByType(ScoreTypeEnum type) {
        Score score = null;

        switch (type) {
            case CREDIT:
                score = iatm.getCreditScore();
                break;
            case DEBET:
                score = iatm.getDebetScore();
                break;
            case CURRENT:
                score = iatm.getCurrentScore();
                break;
        }

        return score;
    }

    public void setCreditScore(CreditScore creditScore) {
        iatm.setCreditScore(creditScore);
    }

    public void setDebetScore(DebetScore debetScore) {
        iatm.setDebetScore(debetScore);
    }

    public void setCurrentScore(CurrentScore currentScore) {
        iatm.setCurrentScore(currentScore);
    }
}
