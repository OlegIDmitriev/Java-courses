package ru.raiffeisen.cources.atm.soapclient;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import ru.raiffeisen.cources.atm.ScoreTypeEnum;
import ru.raiffeisen.cources.atm.TestPair;
import ru.raiffeisen.cources.atm.model.money.Money;
import ru.raiffeisen.cources.atm.soapclient.ATMClient;
import ru.raiffeisen.cources.atm.soapclient.ATMClientDataSupplier;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ATMClientTest {
    private static ATMClient atmClient = new ATMClient();
    private static ATMClientDataSupplier dataSupplier = new ATMClientDataSupplier();

    @BeforeEach
    public void setInitialScores(){
        dataSupplier.setInitialScore(atmClient);
    }

    @Test
    public void getCreditScore(){
        assertEquals(dataSupplier.getInitialCreditScore(), atmClient.getCreditScore());
    }

    @Test
    public void getDebetScore(){
        assertEquals(dataSupplier.getInitialDebetScore(), atmClient.getDebetScore());
    }

    @Test
    public void getCurrentScore(){
        assertEquals(dataSupplier.getInitialCurrentScore(), atmClient.getCurrentScore());
    }

    @ParameterizedTest
    @EnumSource(ScoreTypeEnum.class)
    public void addMoneyToScore(ScoreTypeEnum type){
        TestPair<Money> moneyPair = dataSupplier.pairForAddMoney();

        atmClient.addMoneyToScore(moneyPair.getTestValue(), type);
        assertEquals(moneyPair.getExpectedValue(), atmClient.getScoreByType(type).getBalance());

    }

    @ParameterizedTest
    @EnumSource(ScoreTypeEnum.class)
    public void getMoneyFromScore(ScoreTypeEnum type){
        TestPair<Money> moneyPair = dataSupplier.pairForGetMoney();

        assertEquals(moneyPair.getExpectedValue(), atmClient.getMoneyFromScore(moneyPair.getTestValue(), type));

    }
}
