package ru.raiffeisen.cources.atm.soapclient;

import ru.raiffeisen.cources.atm.ATM;
import ru.raiffeisen.cources.atm.TestPair;
import ru.raiffeisen.cources.atm.model.money.Money;
import ru.raiffeisen.cources.atm.model.score.CreditScore;
import ru.raiffeisen.cources.atm.model.score.CurrentScore;
import ru.raiffeisen.cources.atm.model.score.DebetScore;
import ru.raiffeisen.cources.atm.soap.IATM;

public class ATMClientDataSupplier {
    private ATM atm = new ATM();

    public ATMClient getInitialATMClient(){
        return new ATMClient();
    }

    public CreditScore getInitialCreditScore(){
        return atm.getCreditScore();
    }

    public DebetScore getInitialDebetScore(){
        return atm.getDebetScore();
    }

    public CurrentScore getInitialCurrentScore(){
        return atm.getCurrentScore();
    }

    public TestPair<Money> pairForAddMoney(){
        Money money1 = new Money(100, "RUR");
        Money money1Ex = new Money(1100, "RUR");
        TestPair<Money> pair = new TestPair<>(money1, money1Ex);

        return pair;
    }

    public TestPair<Money> pairForGetMoney(){
        Money money1 = new Money(99, "RUR");
        Money money1Ex = new Money(901, "RUR");
        TestPair<Money> pair = new TestPair<>(money1, money1Ex);

        return pair;
    }

    public void setInitialScore(ATMClient atmClient){
        /*
        atmClient.getCreditScore().setBalance(new Money(1000, "RUR"));
        atmClient.getDebetScore().setBalance(new Money(1000, "RUR"));
        atmClient.getCurrentScore().setBalance(new Money(1000, "RUR"));
        */
        atmClient.setCreditScore(getInitialCreditScore());
        atmClient.setDebetScore(getInitialDebetScore());
        atmClient.setCurrentScore(getInitialCurrentScore());

    }
}
