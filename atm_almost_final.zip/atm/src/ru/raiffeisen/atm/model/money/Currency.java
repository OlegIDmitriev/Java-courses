package ru.raiffeisen.atm.model.money;

public class Currency {
    private String name;
    private float rurCource;

    public Currency(String name, float rurCource) {
        this.name = name;
        this.rurCource = rurCource;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getRurCource() {
        return rurCource;
    }

    public void setRurCource(float rurCource) {
        this.rurCource = rurCource;
    }

    @Override
    public String toString() {
        return "Currency{" +
                "name='" + name + '\'' +
                ", rurCource=" + rurCource +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Currency currency = (Currency) o;

        if (Float.compare(currency.rurCource, rurCource) != 0) return false;
        return name != null ? name.equals(currency.name) : currency.name == null;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (rurCource != +0.0f ? Float.floatToIntBits(rurCource) : 0);
        return result;
    }
}
