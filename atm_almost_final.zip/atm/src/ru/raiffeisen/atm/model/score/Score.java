package ru.raiffeisen.atm.model.score;

import ru.raiffeisen.atm.annotations.Loggable;
import ru.raiffeisen.atm.annotations.MethodLimit;
import ru.raiffeisen.atm.annotations.OperationLimit;
import ru.raiffeisen.atm.model.account.Account;
import ru.raiffeisen.atm.model.money.Money;
import ru.raiffeisen.atm.model.money.MoneyInterface;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

@Loggable
@OperationLimit(value = 10000)
public abstract class Score implements MoneyInterface {
    private static double operationSum = 0;
    private int methodCount = 0;
    private Money balance;
    private Account owner;
    private Integer number;

    public Score(Money balance, Account owner, Integer number) {
        this.balance = balance;
        this.owner = owner;
        this.number = number;
    }

    public Money getBalance() {
        log("Вызван метод getBalance()");

        return balance;
    }

    public void setBalance(Money balance) {
        log("Вызван метод setBalance()");

        this.balance = balance;
    }

    public Account getOwner() {
        log("Вызван метод getOwner()");

        return owner;
    }

    public void setOwner(Account owner) {
        log("Вызван метод setOwner()");

        this.owner = owner;
    }

    @Override
    public boolean equals(Object o) {
        log("Вызван метод equals()");

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Score score = (Score) o;

        if (balance != null ? !balance.equals(score.balance) : score.balance != null) return false;
        if (owner != null ? !owner.equals(score.owner) : score.owner != null) return false;
        return number != null ? number.equals(score.number) : score.number == null;
    }

    @Override
    public int hashCode() {
        int result = balance != null ? balance.hashCode() : 0;
        result = 31 * result + (owner != null ? owner.hashCode() : 0);
        result = 31 * result + (number != null ? number.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        log("Вызван метод toString()");

        return "Score{" +
                "balance=" + balance +
                ", owner=" + owner +
                ", number=" + number +
                '}';
    }

    public Integer getNumber() {
        log("Вызван метод getNumber()");

        return number;
    }

    public void setNumber(Integer number) {
        log("Вызван метод setNumber()");

        this.number = number;
    }

    @MethodLimit(value = 5)
    @Override
    public void addMoney(Money money) {
        log("Вызван метод addMoney()");

        if (checkMethodLimit("addMoney")) {
            methodCount++;
        } else {
            System.out.println("Превышен лимит вызова!");
            return;
        }

        double rurValueIn = money.getValue() * money.getCurrency().getRurCource();
        double rurValueThis = this.balance.getValue() * this.balance.getCurrency().getRurCource();

        if (rurValueThis < rurValueIn) {
            System.out.println("You have no so much!");
            return;
        }

        if (checkOperationLimit(rurValueIn)) {
            this.balance.setValue(this.balance.getValue() + (rurValueIn) / this.balance.getCurrency().getRurCource());
            operationSum += rurValueIn;
        } else {
            System.out.println("Превышен лимит операций!");
        }
    }

    @MethodLimit(value = 1)
    @Override
    public Money getMoney(double balanceLess) {
        log("Вызван метод getMoney()");

        if (checkMethodLimit("getMoney")) {
            methodCount++;
        } else {
            System.out.println("Превышен лимит вызова!");
            return null;
        }

        if (balanceLess > 30000) {
            throw new IllegalArgumentException("Wrong balance less!");
        }

        if (checkOperationLimit(balanceLess)) {
            this.balance.setValue(this.balance.getValue() - balanceLess);
            operationSum += balanceLess;
        } else {
            System.out.println("Превышен лимит операций!");
        }

        return this.balance;
    }

    @MethodLimit(value = 1)
    @Override
    public Money getMoneyWithoutLess() {
        log("Вызван метод getMoneyWithoutLess()");

        if (checkMethodLimit("getMoneyWithoutLess")) {
            methodCount++;
        } else {
            System.out.println("Превышен лимит вызова!");
            return null;
        }

        return this.balance;
    }

    abstract boolean checkBefore();

    private boolean checkOperationLimit(double rurSumIn) {
        log("Вызван метод checkOperationLimit()");

        double rurValueThis = this.balance.getValue() * this.balance.getCurrency().getRurCource();

        Class thisClass = this.getClass();
        for (Annotation a : thisClass.getAnnotations()) {
            if (a instanceof OperationLimit) {
                OperationLimit operationLimit = (OperationLimit) a;

                if ((rurSumIn + operationSum) > operationLimit.value()) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean checkMethodLimit(String methodName) {
        log("Вызван метод checkMethodLimit()");

        Class thisClass = this.getClass();
        Method[] methods = thisClass.getMethods();
        Method method = null;
        for (Method m : methods) {
            if (m.getName().equals(methodName)) {
                method = m;
                break;
            }
        }
        if (method == null) {
            return true;
        }

        for (Annotation a : method.getAnnotations()) {
            if (a instanceof MethodLimit) {
                MethodLimit methodLimit = (MethodLimit) a;

                if (methodCount >= methodLimit.value()) {
                    return false;
                }
            }
        }
        return true;
    }

    private void log(String message) {
        for (Annotation a : Score.class.getAnnotations()) {
            if (a instanceof Loggable) {
                System.out.println(message);
            }
        }
    }

    public static double getOperationSum() {
        return operationSum;
    }

    public int getMethodCount() {
        return methodCount;
    }
}
