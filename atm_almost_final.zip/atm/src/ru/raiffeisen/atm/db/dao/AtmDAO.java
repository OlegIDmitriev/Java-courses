package ru.raiffeisen.atm.db.dao;

import ru.raiffeisen.atm.db.connection.IConnectionManager;
import ru.raiffeisen.atm.model.account.Account;
import ru.raiffeisen.atm.model.account.Principal;
import ru.raiffeisen.atm.model.money.Money;
import ru.raiffeisen.atm.model.score.CreditScore;
import ru.raiffeisen.atm.model.score.CurrentScore;
import ru.raiffeisen.atm.model.score.DebetScore;
import ru.raiffeisen.atm.model.score.Score;
import ru.raiffeisen.atm.ATM;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class AtmDAO extends AbstractDAO {
    public AtmDAO(IConnectionManager connectionManager) {
        super(connectionManager);
    }

    private Map<Integer, Principal> getAllPrincipals() {
        Map<Integer, Principal> principals = new HashMap<>();

        Statement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .createStatement();

            ResultSet rs = statement.executeQuery("SELECT * FROM public.principal");

            while (rs.next()) {
                Principal principal = new Principal(rs.getString(2), rs.getString(3), rs.getString(4), rs.getShort(5));
                int id = rs.getInt(1);

                principals.put(id, principal);
            }
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

        return principals;
    }

    private Map<Integer, Account> getAllAccounts() {
        Map<Integer, Account> accounts = new HashMap<>();
        Map<Integer, Principal> principals = getAllPrincipals();

        Statement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .createStatement();

            ResultSet rs = statement.executeQuery("SELECT * FROM public.account");


            while (rs.next()) {
                Account account = new Account(principals.get(rs.getInt(1)), rs.getString(3), rs.getString(4));
                int id = rs.getInt(1);

                accounts.put(id, account);
            }
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

        return accounts;
    }

    /*private Map<Integer, Currency> getAllCurrencies() {
        Map<Integer, Currency> currencies = new HashMap<>();

        Statement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .createStatement();

            ResultSet rs = statement.executeQuery("SELECT * FROM public.currency");


            while (rs.next()) {
                Currency currency = new Currency(rs.getString(3), rs.getFloat(2));
                int id = rs.getInt(1);

                currencies.put(id, currency);
            }
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

        return currencies;
    }*/

    private Map<Integer, Money> getAllMoney() {
        Map<Integer, Money> moneyMap = new HashMap<>();

        Statement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .createStatement();

            ResultSet rs = statement.executeQuery("SELECT * FROM public.money");


            while (rs.next()) {
                Money money = new Money(rs.getDouble(2), rs.getString(3));
                int id = rs.getInt(1);

                moneyMap.put(id, money);
            }
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

        return moneyMap;
    }

    public List<ATM> getAllATM() {
        List<ATM> atmList = new ArrayList<>();
        Map<Integer, Money> moneyMap = getAllMoney();
        Map<Integer, Account> accounts = getAllAccounts();

        Statement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .createStatement();

            ResultSet rs = statement.executeQuery("SELECT at.*, cres.*, curs.*, debs.* FROM public.atm at \n" +
                    "JOIN public.credit_score cres ON cres.id = at.credit_score_id\n" +
                    "JOIN public.current_score curs ON curs.id = at.current_score_id\n" +
                    "JOIN public.debet_score debs ON debs.id = at.debet_score_id");

            while (rs.next()) {
                CreditScore creditScore = null;
                CurrentScore currentScore = null;
                DebetScore debetScore = null;


                creditScore = new CreditScore(moneyMap.get(rs.getInt(6)), accounts.get(rs.getInt(7)), rs.getInt(8));
                debetScore = new DebetScore(moneyMap.get(rs.getInt(14)), accounts.get(rs.getInt(15)), rs.getInt(16), creditScore);
                currentScore = new CurrentScore(moneyMap.get(rs.getInt(10)), accounts.get(rs.getInt(11)), rs.getInt(12), debetScore);

                ATM atm = new ATM(currentScore, debetScore, creditScore);

                atmList.add(atm);
            }
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

        return atmList;
    }

    public void writeDBDump(ATM atm) {
        if(atm == null){
            return;
        }

        //На случай, если счета имеют разные аккаунты
        Map<Account, Integer> accountsId = new HashMap<>();
        accountsId.put(atm.getCreditScore().getOwner(), null);
        accountsId.put(atm.getCurrentScore().getOwner(), null);
        accountsId.put(atm.getDebetScore().getOwner(), null);

        for(Account a : accountsId.keySet()){
            accountsId.put(a, writeAccountToDB(a));
        }

        int credit_id = writeScoreToDB(atm.getCreditScore(), accountsId.get(atm.getCreditScore().getOwner()));
        int current_id = writeScoreToDB(atm.getCurrentScore(), accountsId.get(atm.getCurrentScore().getOwner()));
        int debet_id = writeScoreToDB(atm.getDebetScore(), accountsId.get(atm.getDebetScore().getOwner()));

        PreparedStatement statementAtm = null;

        try {
            statementAtm = super.connectionManager.getConnection()
                    .prepareStatement("INSERT INTO public.atm (credit_score_id, current_score_id, debet_score_id) VALUES (?, ?, ?)");

            statementAtm.setInt(1, credit_id);
            statementAtm.setInt(2, current_id);
            statementAtm.setInt(3, debet_id);

            statementAtm.executeUpdate();

        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }


    }

    private int writeScoreToDB(Score score, int account_id) {
        int index = -1;

        String tableName;
        if (score instanceof CreditScore) {
            tableName = "credit_score";
        } else if (score instanceof CurrentScore) {
            tableName = "current_score";
        } else {
            tableName = "debet_score";
        }

        String insertQuery = "INSERT INTO public." + tableName + " (money_id, account_id, number) VALUES (?, ?, ?)";
        String selectQuery = "SELECT MAX(id) FROM public." + tableName;
        PreparedStatement statement = null;

        try {
            statement = super.connectionManager.getConnection().prepareStatement(insertQuery);

            statement.setInt(1, writeMoneyToDB(score.getBalance()));
            if (account_id == -1) {
                statement.setNull(2, java.sql.Types.INTEGER);
            } else {
                statement.setInt(2, account_id);
            }
            statement.setInt(3, score.getNumber());

            statement.executeUpdate();

            Statement statementIndex = super.connectionManager.getConnection().createStatement();
            ResultSet rs = statementIndex.executeQuery(selectQuery);
            rs.next();
            index = rs.getInt(1);

        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }
        return index;

    }

    private int writeMoneyToDB(Money money) {
        int index = -1;

        if (money == null) {
            return index;
        }

        PreparedStatement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .prepareStatement("INSERT INTO public.money (currency_name, value) VALUES (?, ?)");

            statement.setString(1, money.getCurrency().getName());
            statement.setDouble(2, money.getValue());

            statement.executeUpdate();

            Statement statement2 = super.connectionManager.getConnection().createStatement();
            ResultSet rs = statement2.executeQuery("SELECT MAX(id) FROM public.money");

            rs.next();
            index = rs.getInt(1);
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

        return index;
    }

    private int writePrincipalToDB(Principal principal) {
        int index = -1;

        if (principal == null) {
            return index;
        }

        PreparedStatement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .prepareStatement("INSERT INTO public.principal (first_name, last_name, second_name, age) VALUES (?, ?, ?, ?)");

            statement.setString(1, principal.getFirstName());
            statement.setString(2, principal.getLastName());
            statement.setString(3, principal.getSecondName());
            statement.setInt(4, principal.getAge());

            statement.executeUpdate();
            Statement statement2 = super.connectionManager.getConnection()
                    .createStatement();
            ResultSet rs = statement2.executeQuery("SELECT MAX(id) FROM public.principal");

            rs.next();
            index = rs.getInt(1);
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

        return index;
    }

    private int writeAccountToDB(Account account) {
        int index = -1;

        if (account == null) {
            return index;
        }

        int principal_id = writePrincipalToDB(account.getPrincipal());

        PreparedStatement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .prepareStatement("INSERT INTO public.account (principal_id, login, password) VALUES (?, ?, ?);");

            if (principal_id == -1) {
                statement.setNull(1, java.sql.Types.INTEGER);
            } else {
                statement.setInt(1, principal_id);
            }

            statement.setString(2, account.getLogin());
            statement.setString(3, account.getPassword());

            statement.executeUpdate();
            Statement statement2 = super.connectionManager.getConnection().createStatement();
            ResultSet rs = statement2.executeQuery("SELECT MAX(id) FROM public.account");

            rs.next();
            index = rs.getInt(1);
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

        return index;
    }

    public void clearDB() {

        Statement statement = null;

        try {
            statement = super.connectionManager.getConnection()
                    .createStatement();

            statement.executeUpdate("DELETE FROM public.atm");
            statement.executeUpdate("DELETE FROM public.credit_score");
            statement.executeUpdate("DELETE FROM public.current_score");
            statement.executeUpdate("DELETE FROM public.debet_score");
            statement.executeUpdate("DELETE FROM public.account");
            statement.executeUpdate("DELETE FROM public.principal");
            statement.executeUpdate("DELETE FROM public.money");

        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }

    }

    public boolean checkDump() {
        boolean isDumpExisted = false;

        Statement statement = null;

        try {
            statement = super.connectionManager.getConnection().createStatement();

            ResultSet rs = statement.executeQuery("SELECT COUNT(*) FROM public.atm");

            rs.next();
            if (rs.getInt(1) > 0) {
                isDumpExisted = true;
            }
        } catch (SQLException sqlEX) {
            sqlEX.printStackTrace();
        }
        return isDumpExisted;
    }

}
