package ru.raiffeisen.atm;

import ru.raiffeisen.atm.db.connection.SingleConnectionManager;
import ru.raiffeisen.atm.db.dao.AtmDAO;
import ru.raiffeisen.atm.model.account.Account;
import ru.raiffeisen.atm.model.account.Principal;
import ru.raiffeisen.atm.model.money.Money;
import ru.raiffeisen.atm.model.score.CreditScore;
import ru.raiffeisen.atm.model.score.CurrentScore;
import ru.raiffeisen.atm.model.score.DebetScore;
import ru.raiffeisen.atm.model.score.Score;
import ru.raiffeisen.proxy.ATMHandler;


import java.lang.reflect.Proxy;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        AtmDAO atmDAO = new AtmDAO(new SingleConnectionManager());
        ATMInterface atm = null;

        Scanner sc = new Scanner(System.in);
        if (atmDAO.checkDump()) {
            System.out.println("Обнаружен сохраненный дамп. Наберите 'yes' чтобы загрузить или любой другой текст чтобы удалить");
            String answer = sc.next();
            if ("yes".equals(answer)) {
                List<ATM> atmList = atmDAO.getAllATM();
                atm = atmList.get(atmList.size() - 1);
            } else {
                atmDAO.clearDB();

            }
        }

        Principal principal = new Principal("John", "Dow", "James", (short) 31);
        Account account = new Account(principal, "login", "password");

        Money creditMoney = new Money(101.06d, "RUR");
        Money currentMoney = new Money(154567.01d, "RUR");
        Money debetMoney = new Money(11354.45d, "RUR");

        CreditScore creditScore = new CreditScore(creditMoney, account, 101);
        DebetScore debetScore = new DebetScore(debetMoney, account, 103, creditScore);
        CurrentScore currentScore = new CurrentScore(currentMoney, account, 102, debetScore);

        atm = new ATM(currentScore, debetScore, creditScore);
        ATMInterface atmProxy =(ATMInterface) Proxy.newProxyInstance(ATM.class.getClassLoader(), ATM.class.getInterfaces(), new ATMHandler(atm));

        atmProxy.getCurrentScore().addMoney(new Money(10d, "RUR"));
        System.out.println(atmProxy.getCurrentScore().getMoneyWithoutLess());

        System.out.println(Score.getOperationSum());
        System.out.println(atmProxy.getCurrentScore().getMethodCount());

        atmDAO.writeDBDump((ATM) atm);
    }
}
