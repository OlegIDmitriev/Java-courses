package cources;

import cources.data.DriverPool;
import cources.data.UserPool;
import cources.elements.OrderPosition;
import cources.pages.DeliveryClubMainPageObject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en_scouse.An;
import org.openqa.selenium.WebDriver;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class MainPageTest {
    private DeliveryClubMainPageObject page;

    @Given("^Go to (https://.*)$")
    public void preCondition(String url) {
        page = new DeliveryClubMainPageObject();
        page.init(DriverPool.instance.pollDriver());

        page.openMainPage();
        page.authorise();

    }

    @When("enter address (.*)")
    public void enterAddress(String address) {
        page.searchByAddress(address);
        page.loadVendors();
    }

    @And("^choose vendor (.*)$")
    public void chooseVendor(String name){
       page.chooseVendor(name);
    }

    @And("^order dish$")
    public void orderDish(List<String> dishes){
        page.loadDishes();

        for(String dish : dishes){
            page.orderDish(dish);
        }

        page.loadOrderPositions();
    }

    @Then("^we see (\\d+) results$")
    public void checkCorrectAddressSearch(int resultCount) {
        System.out.println(page.getVendors().size());

        assertEquals(resultCount, page.getVendors().size());
        page.releaseUser();
        //page.releaseDriver();
    }

    @Then("^we see something$")
    public void checkVendorChoose() {
        System.out.println("We are here!");
        page.releaseUser();
        //page.releaseDriver();
    }

    @Then("^we see error message (.*)$")
    public void checkIncorrectResults(String message) {
        System.out.println(page.getVendors().size());

        assertEquals(message, page.getErrorMessage());
        //page.releaseDriver();
        page.releaseUser();
    }

    @Then("^we see in basket$")
    public void checkBasket(List<String> productsNames){
        for(String name: productsNames){
            assertNotNull(page.getOrderPositionByName(name));
        }
        page.releaseUser();
    }
}
