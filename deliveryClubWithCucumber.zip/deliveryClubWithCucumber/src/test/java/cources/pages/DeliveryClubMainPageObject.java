package cources.pages;

import cources.data.DriverPool;
import cources.data.User;
import cources.data.UserPool;
import cources.elements.*;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class DeliveryClubMainPageObject extends AbstractPage {
    private WebDriver driver;
    private User user;

    @FindBy(id = "user-addr__input")
    private WebElement addrInput;

    @FindBy(className = "user-addr__submit")
    private WebElement searchSubmitBtn;

    @FindBy(className = "authorization-btn--enter")
    private WebElement authBtn;

    @FindBy(className = "tooltip-v2__error")
    private WebElement errorMessage;

    private WebDriverWait waiter;

    private EditableTextField searchMealField;
    private CheckBox checkBoxPizza;

    private List<CheckBox> checkBoxList = new ArrayList<CheckBox>();
    private List<CheckBox> checkBoxListAll = new ArrayList<CheckBox>();
    private Map<String, Vendor> vendors = new HashMap<String, Vendor>();
    private Map<String, Dish> dishes = new HashMap<String, Dish>();
    private List<OrderPosition> orderList = new ArrayList<OrderPosition>();

    @Override
    public void init(WebDriver webDriver) {
        this.driver = webDriver;
        this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        waiter = new WebDriverWait(driver, 15);
        PageFactory.initElements(webDriver, this);
        user = UserPool.instance.pollUser();
    }

    public void gotoFoodEntity() {
        driver.get("https://www.delivery-club.ru/entities/food/?address=%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C%20%D0%A8%D0%B0%D1%80%D0%B8%D0%BA%D0%BE%D0%BF%D0%BE%D0%B4%D1%88%D0%B8%D0%BF%D0%BD%D0%B8%D0%BA%D0%BE%D0%B2%D1%81%D0%BA%D0%B0%D1%8F%20%D1%83%D0%BB%D0%B8%D1%86%D0%B0%2C%2017&cat_id=1&district=&min_sum=5000&mo_mode=&mode=food&no_city=&okrug=&show=opened");

        List<WebElement> checkBoxes =
                driver.findElements(
                        By.xpath("//label[@class='vendors-filter__item']/input"));

        checkBoxes.clear();
        for (WebElement elem :
                checkBoxes) {
            CheckBox checkBox = new CheckBox(elem);
            checkBoxListAll.add(checkBox);
        }
    }

    public void checkSomeCheckBoxByName(String name) {
        for (CheckBox checkBox :
                checkBoxListAll) {
            if (checkBox.getName().equals(name)) {
                checkBox.check();
            }
        }
    }

    public void uncheckSomeCheckBoxByName(String name) {
        for (CheckBox checkBox :
                checkBoxListAll) {
            if (checkBox.getName().equals(name)) {
                checkBox.unCheck();
            }
        }
    }

    public void auth(String login, String password) {
        authBtn.click();

        EditableTextField loginField =
                new EditableTextField(driver.findElement(By.className("user-login__input")));
        loginField.appendText(login);

        //EditableTextField passField = new EditableTextField(driver.findElement(By.))
    }

    public CheckBox getCheckBoxNyName(String name) {
        for (CheckBox checkBox :
                checkBoxList) {
            if (checkBox.getName().equals(name)) {
                return checkBox;
            }
        }

        return null;
        //return checkBoxList.stream().filter(checkBox -> checkBox.getName().equals(name)).findFirst().get();
    }

    public void searchByAddr(String address) {
        fillAddrField(address);
        searchSubmitBtn.click();

        checkBoxPizza =
                new CheckBox(
                        waiter.until(
                                ExpectedConditions
                                        .presenceOfElementLocated(
                                                By.xpath("//input[./following-sibling::span[contains(.,'Пицца')]]")
                                        )
                        )
                );
    }

    public void searchByAddress(String address) {
        fillAddrField(address);

        //waiter.until(ExpectedConditions.presenceOfElementLocated(By.linkText("/entities/food/#all")));
        searchSubmitBtn.click();
    }

    public void fillAddrField(String address) {
        waiter.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-addr__input")));
        addrInput.clear();
        addrInput.sendKeys(address);
    }

    public String getErrorMessage() {
        return errorMessage.getText().trim();
    }

    public void gotoMenu(String menuName) {
        WebElement menuLink =
                driver.findElement(By.linkText(menuName));

        if (menuLink != null) {
            menuLink.click();

            List<WebElement> checkBoxes =
                    driver.findElements(
                            By.xpath("//div[@class='vendors-filter__items-visible']/label/input"));

            checkBoxes.clear();
            for (WebElement elem :
                    checkBoxes) {
                CheckBox checkBox = new CheckBox(elem);
                checkBoxList.add(checkBox);
            }

            //checkBoxes.stream().map(elem -> new CheckBox(elem)).collect(Collectors.toList());
        }
    }

    public List<CheckBox> getCheckBoxList() {
        return checkBoxList;
    }

    public void gotoPizzaMenu() {
        WebElement pizzaMenuLink =
                driver.findElement(By.linkText("Пицца"));

        if (pizzaMenuLink != null) {
            pizzaMenuLink.click();

            searchMealField =
                    new EditableTextField(waiter.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@class='search-form__input input--def']")))
                    );
        }
    }

    public EditableTextField getSearchMealField() {
        return searchMealField;
    }

    public CheckBox getCheckBoxPizza() {
        return checkBoxPizza;
    }

    public void loadVendors() {
        List<WebElement> elements;
        vendors.clear();

        try {
            elements = driver.findElements(By.className("vendor-item__card"));

            for (WebElement element : elements) {
                Vendor vendor = new Vendor(element);
                vendors.put(vendor.getVendorName(), vendor);
            }
        } catch (StaleElementReferenceException e) {
            loadVendors();
        }
    }

    public Map<String, Vendor> getVendors() {
        return vendors;
    }

    public Vendor getVendorByName(String name) {
        return vendors.get(name);
    }

    public void chooseVendor(String name) {
        Vendor vendor = getVendorByName(name);
        if (vendor != null) {
            vendor.click();
        }
    }

    public void loadDishes() {
        List<WebElement> elements;
        dishes.clear();

        try {
            elements = waiter.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//li[contains(@class, 'dish')]")));

            for (WebElement element : elements) {
                Dish dish;
                if (element.findElement(By.xpath("./form/p/a")).getAttribute("class").equals("button show-ingr-popup")) {
                    dish = new Pizza(element, waiter, driver);
                } else {
                    dish = new Dish(element, waiter, driver);
                }
                dishes.put(dish.getProductTitle(), dish);
            }
        } catch (StaleElementReferenceException e) {
            loadDishes();
        }
    }

    public Dish getDishByName(String name) {
        return dishes.get(name);
    }

    public void orderDish(String name) {
        Dish dish = getDishByName(name);
        if (dish != null) {
            dish.order();
        }
    }

    public void openMainPage() {
        driver.get("https://www.delivery-club.ru/");
    }

    public void openBasket() {
        WebElement basketBtn = driver.findElement(By.xpath("//a[contains(@class, 'button alt open_basket from_basket')]"));
        basketBtn.click();
    }

    public void loadOrderPositions() {
        List<WebElement> elements;
        orderList.clear();

        openBasket();

        try {
            elements = waiter.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//ul[contains(@class, 'user_basket__list')]/li")));

            for (WebElement element : elements) {
                OrderPosition order = new OrderPosition(element);
                orderList.add(order);
            }
        } catch (StaleElementReferenceException e) {
            loadOrderPositions();
        }

    }

    public OrderPosition getOrderPositionByName(String name) {
        for (OrderPosition order : orderList) {
            if (order.getProductName().equals(name)) {
                return order;
            }
        }
        return null;
    }


    public void authorise() {
        waiter.until(ExpectedConditions.presenceOfElementLocated(By.className("authorization-btn--enter")));
        authBtn.click();

        EditableTextField loginField = new EditableTextField(waiter.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@class='user-login__form']/label[1]/input"))));
        loginField.enterText(user.getEmail());

        EditableTextField passField = new EditableTextField(waiter.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@class='user-login__form']//input[@type='password']"))));
        passField.enterText(user.getPassword());

        WebElement authSubmitBtn = waiter.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[@class='user-login__form']/button[not(contains(@class, 'tmp-disabled'))]")));
        authSubmitBtn.click();

        waiter.until(ExpectedConditions.presenceOfElementLocated(By.id("user-profile")));

    }

    public void releaseDriver() {
        DriverPool.instance.releaseDriver(driver);
    }

    public void releaseUser() {
        UserPool.instance.releaseUser(user);
    }


}
