package cources.data;

import org.openqa.selenium.WebDriver;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class UserPool {
    private List<User> users = new CopyOnWriteArrayList<User>();

    private UserPool(){
        users.add(new User("olleggs@yandex.ru", "Alabama_0729"));
        users.add(new User("olleggs@mail.ru", "Alaska_0729"));
    }

    public synchronized User pollUser(){
        if(users.size() == 0){
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return pollUser();
        }
        User user = users.get(0);
        users.remove(user);
        return user;
    }

    public synchronized void releaseUser(User user){
        users.add(user);
    }

    public static final UserPool instance = new UserPool();
}
