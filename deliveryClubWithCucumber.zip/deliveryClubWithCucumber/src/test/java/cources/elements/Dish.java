package cources.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Dish {
    private WebDriver driver;
    protected WebElement element;
    protected WebDriverWait waiter;
    private String productTitle;
    protected WebElement link;

    public Dish(WebElement element, WebDriverWait waiter, WebDriver driver) {
        this.element = element;
        this.productTitle = element.findElement(By.xpath(".//h3[@class='product_title']/span")).getText();
        this.waiter = waiter;
        this.driver = driver;

    }

    public void scrollDown() {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,150)", "");
    }

    public void moceToElement() {
        Actions actions = new Actions(driver);
        actions.moveToElement(element);
        actions.perform();

        scrollDown();
    }

    public void order() {
        link = element.findElement(By.xpath(".//form/p/a"));

        moceToElement();
        link.click();
    }

    public String getProductTitle() {
        return productTitle;
    }
}
