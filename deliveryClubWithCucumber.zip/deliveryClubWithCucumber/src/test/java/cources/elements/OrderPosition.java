package cources.elements;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class OrderPosition {
    private WebElement element;
    private String productName;

    public OrderPosition(WebElement element) {
        this.element = element;
        this.productName = element.findElement(By.xpath("./dl[@class='product_info']/dt")).getText();
    }

    public String getProductName() {
        return productName;
    }
}
