package cources.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Pizza extends Dish {

    public Pizza(WebElement element, WebDriverWait waiter, WebDriver driver) {
        super(element, waiter, driver);
    }

    @Override
    public void order() {
        link = element.findElement(By.xpath(".//form/p/a"));

        moceToElement();
        link.click();

        WebElement orderBtn = waiter.until(ExpectedConditions.elementToBeClickable(By.className("popup-dish__btn--add")));
        orderBtn.click();
    }
}
